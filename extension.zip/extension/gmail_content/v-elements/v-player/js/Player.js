
	VPlayer = function () {

		var public = {

			

		};

		return public;

	}