
	( function () {

		chrome.extension.getBackgroundPage().transferControl( window );

	} () )